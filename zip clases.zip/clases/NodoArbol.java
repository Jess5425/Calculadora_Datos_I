public class NodoArbol {
    String data;
    NodoArbol left;
    NodoArbol right;
    NodoArbol next;

    public NodoArbol(){
        this.data=null;
        this.next=null;
        this.left=null;
        this.right=null;
    }
}

