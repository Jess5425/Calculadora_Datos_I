public class Nodo {
    String data;
    Nodo next;

    public Nodo(String input){
        this.data=input;
        this.next=null;
    }
}
